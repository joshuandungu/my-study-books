package com.packt.android

class TestRandomizer : Randomizer {
    override fun getNumber(): Int {
        return 2
    }
}
