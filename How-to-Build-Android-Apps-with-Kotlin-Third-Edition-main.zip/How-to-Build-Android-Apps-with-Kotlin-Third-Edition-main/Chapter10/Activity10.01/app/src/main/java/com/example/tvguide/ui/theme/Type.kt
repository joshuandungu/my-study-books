package com.example.tvguide.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()