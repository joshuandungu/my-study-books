package com.example.popularmovies.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()